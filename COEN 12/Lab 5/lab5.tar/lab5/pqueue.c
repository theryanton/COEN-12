/* Ryan Ton
 * COEN 12
 * Lab 5
 * Tuesday 5:15pm
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "pqueue.h"
#define p(x) (((x)-1)/2)
#define l(x) (((x)*2)+1)
#define r(x) (((x)*2)+2)

struct pqueue // Struct itself used to represent a priority queue
{
	int count; // Number of elements
	int length; // Length of array
	void **data; // Array used to record data
	int (*compare)(); // Calls compare function, which is provided via huffman.c
};

PQ *createQueue (int (*compare)()) // Function allocates memory and initializes an empty priority queue that keeps record of count of elements, the length of the array (which its start value has been assigned to 10), and an array used to record all our data. Additionally calls our given compare function that was defined earlier in the struct; Runtime: O(1)
{
	PQ *pq;
	pq = malloc(sizeof(PQ)); // Allocates memory for new priority queue
	assert (pq!=NULL);

	pq->count = 0; // Initializes count of elements
	pq->length = 10; // Keeps track of length of array, starting value set to 10
	pq->data = malloc(sizeof(void*)*pq->length); // Allocates memory for array recording data values
	pq->compare = compare;
	assert (pq->data!= NULL);

	return pq;
}

void destroyQueue (PQ *pq) // Destroys the priority queue by iterating and freeing each element in the data array, then freeing the allocated memory for the data array and finally, the queue itself; Runtime: O(n)
{
	assert (pq!=NULL);
	int i;
	for (i=0; i<pq->count; i++) // For loop used to iterate data array
	{
		free (pq->data[i]); // Frees memory allocated for  elements one by one
	}
	free (pq->data); // Frees data array
	free (pq); // Frees priority queue itself
}

int numEntries (PQ *pq) // Simply returns count of elements within priority queue; Runtime: O(1)
{
	assert (pq!=NULL);
	return (pq->count);
}

void addEntry (PQ *pq, void *entry) // Function adds an alement to the end of the array, only after determining whether this addition maintains the min-heap nature of the array. If not, it will perform reheapup and continue swapping the added element with its parent until it fulfills a min-heap. Also, if this addition reaches the length of the array, this function will reallocate and increase the size of the array by a factor of 2; Runtime: O(log n)
{
	assert (pq!=NULL && entry!=NULL);
	if (pq->count + 1 > pq->length) // If the count of elements has reached its limit according to length
	{
		pq->data = realloc(pq->data, sizeof(void*)*pq->length*2); // Reallocate some more memory fot data array by a factor of 2
		pq->length = pq->length * 2; // Increase length array indexes by factor of 2
	}
	pq->data[pq->count] = entry; // Add new element at the end of array

	int index = pq->count; // Variable will be used to keep track of the location within array of the element we're swapping

	while (pq->compare(pq->data[index], pq->data[p(index)]) < 0) // While the min-heap nature of the array isn't fulfilled, reheapup will be performed by continuously comparing with parent
	{
		void* temp = pq->data[p(index)]; // Temporary element used to perform swap
		pq->data[p(index)] = pq->data[index];
		pq->data[index] = temp; // If the child is smaller than the parent, perform swap
		index = p(index);
	}
	pq->count++; // Increment total count of elements
}

void *removeEntry (PQ *pq) // Function removes first the element within the array, due to its nature as a priority queue, and replaces that index with the last element within the array, performing reheapdown. Checking whether the new first element has children, if it has 2 children, we use the compare function to check which child is smaller. If the smaller child node is smaller than its parent, we then swap the parent with that node to maintain the min-heap. Otherwise, if it only has a left child, we check if it's smaller than the parent. If it is, we perform a swap. Finally, we return the deleted element; Runtime: O(log n)
{
	assert (pq!=NULL);
	void* root = pq->data[0]; // Pointer to the first element's data, which is returned at the end of the function
	int index = 0; // Keeps track of the index of the element we are swapping
	int smallestIndex = 0; // Keeps track of the smallest child element
	pq->data[index] = pq->data[pq->count-1]; // Replaces the first element within array with the last element in queue
	pq->count--; // Decrement total count of elements

	while (l(index) < pq->count) // While there is a left child
	{
		smallestIndex = l(index);
		if (r(index) < pq->count) // If a right child exists, we now have to compare between both children
		{
			if (pq->compare(pq->data[l(index)], pq->data[r(index)]) < 0) // Calls compare function, if right child is the smaller one
			{
				smallestIndex=l(index); // Set smallest index as index of left child
			}
			else
			{
				smallestIndex=r(index); // Set smallest index as index of right child
			}
		}
		if (pq->compare(pq->data[smallestIndex], pq->data[index]) < 0) // Uses the smallest child's index to perform swap with parent element
		{
			void* temp = pq->data[smallestIndex];// Temporary element used to perform swap
			pq->data[smallestIndex] = pq->data[index];
			pq->data[index] = temp;
			index=smallestIndex;
		}
		else
		{
			break;
		}
	}
	return root; // Return deleted element's data
}
