/* Ryan Ton
 * COEN 12
 * Lab 5
 * Tuesday 5:15pm
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ctype.h>
#include "pack.h"
#include "pqueue.h"

typedef struct node NODE; // Reference to struct defined in pqueue.c in order to perform Huffman coding to build a tree bottom-up and compress files

int hopNumber (struct node *leaf) // Function takes in a leaf of the huffman and traverses the tree until reaching the root. As its traversing, it keeps track of the number of hops it takes to reach the root; Runtime: O(n)
{
	int hops = 0; // Initiates count of hops
	while (leaf->parent !=NULL) // While loop to traverse tree
	{
		leaf = leaf->parent;
		hops++;
	}
	return hops;
}

int compare (struct node *first, struct node *second) // Operates similarly to integer compare, however is used to compare between data within 2 nodes; Runtime: O(1)
{
	return (first->count < second->count) ? -1 : (first->count > second->count);
}

int main (int argc, char *argv[]) // Runtime: O(log n)
{
/* First, count number of occurences of a specific character appearing in a file via the fgetc function provided to us, until reaching the end of the file. Each time, we increment the counter at index corresponding to the character's ascii value */
	FILE *fp = fopen(argv[1],"r"); // Open file
	if (fp==NULL) // If file doesn't exist
	{
		return 0;
	}
	int i;
	int occurences[257] = {0}; // Initialized occurences array of size 257, leaving an extra index for end of file
	do { // Do while loop, used to continuously grab next character
		int c;
		c = fgetc(fp);
		if ( feof(fp) ) // If end of file is reached
		{
			break;
		}
		occurences[c]++;
	} while (1);

/* Next, create a priority queue which stores all trees and leaf nodes */
	PQ *pqueue = createQueue (compare);
	struct node* leaves[257] = {0};
	for (i=0; i<257; i++) // Creates a new array to keep track of leaves
	{
		leaves[i] = NULL;
	}
	for (i=0; i<256; i++) // For each nonzero count, a new node is created for it and added to the priority queue and the leaves array
	{
		if (occurences[i] > 0)
		{
			NODE *thenode=malloc(sizeof(struct node));
			thenode->count = occurences[i];
			thenode->parent = NULL;
			addEntry(pqueue, thenode);
			leaves[i] = thenode;
		}
	}
	NODE *zeroCountNode = malloc(sizeof(struct node)); // Must create a tree with an initial zero count to not leave out the end of file mark
	zeroCountNode->count = 0;
	zeroCountNode->parent = NULL;
	addEntry(pqueue, zeroCountNode);
	leaves[256] = zeroCountNode;

/* Next, we remove the 2 lowest priority trees as long as the priority queue has more than 1 tree in it. We then make a new tree whose data is the sum of the trees we removed. This new tree is inserted back into the priority queue, and the process is repeated until we have one single big tree */
	while (numEntries(pqueue) > 1)
	{
		NODE *first = removeEntry(pqueue); // Calls removeEntry function to remove the 2 lowest priority trees
		NODE *second = removeEntry(pqueue);
		NODE *third = malloc(sizeof(struct node)); // Allocates memory for new third tree
		third->count = first->count + second->count; // Count is the sum of deleted trees
		third->parent = NULL;
	 	first->parent = third;
		second->parent = third;
		addEntry(pqueue, third); // Add new tree to priority queue
	}

/* Next, we traverse the leaves array, and if there's a match for a valid node, we call the hopNumber function to find and return the number of hops it takes to get from the leaf to the tree's root */
	for (i=0; i<257; i++)
	{
		if (leaves[i]!=NULL)
		{
			int totalHops;
			totalHops = hopNumber(leaves[i]);
			if (isprint(i)) // If character is printable
			{
				printf("%c: %d x %d bits = %d\n", i, occurences[i], totalHops, occurences[i]*totalHops);
			}
			else
			{
				printf("%03o: %d x %d bits = %d\n", i, occurences[i], totalHops, occurences[i]*totalHops);
			}
		}
	}

/* Finally, pack the input file using the pack function provided to us */
	pack(argv[1],argv[2],leaves);
}
