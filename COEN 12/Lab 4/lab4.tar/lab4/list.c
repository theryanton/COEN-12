/* Ryan Ton
 * COEN 12
 * Lab 4
 * Tuesday 5:15pm
 */

#include <stdlib.h>
#include <assert.h>
#include "list.h"

struct node
{
	void *data; // Initiated storage for recording data
	struct node *prev; // Pointer points to previous node in list
	struct node *next; // Pointer points to next node in list
};

struct list
{
	int count; // Variable keeps count of all nodes within linked list, excluding dummy node
	struct node *head; // Pointer points to first node in list
	int (*compare)(); // Calls compare function, which is provided to us via project tar file
};

LIST *createList (int (*compare)()) // Function allocates storage and creates a new doubly-linked list, which contains a dummy node, as well as initializing the count of nodes at 0. The next and previous pointers are also pointing to itself because there aren't any other nodes in the list yet; Runtime: O(1)
{
	LIST *lp;
	lp = malloc (sizeof(LIST)); // Allocates storage for new list
	assert (lp != NULL);

	lp->count = 0; // Initializes count of nodes at 0

	lp->head = malloc (sizeof(struct node)); // Inserting new dummy node as head
	lp->head->next = lp->head; // Set next pointer to itself
	lp->head->prev = lp->head; // Set previous pointer to itself

	lp->compare = compare;
	return lp;
}

void destroyList (LIST *lp) // Function continuously calls removeLast function, and deletes the last node in the list excluding the dummy node as long as the count of elements is greater than 0; Runtime: O(n)
{
	assert (lp!=NULL);
	while (lp->count > 0)
	{
		removeLast (lp);
	}
}

int numItems (LIST *lp) // Returns count of elements within the list; Runtime: O(1)
{
	assert (lp!=NULL);
	return lp->count;
}

void addFirst (LIST *lp, void *item) // Inserts node into a list with data at the front end of the queue; Runtime: O(1)
{
	struct node *newNode = malloc (sizeof(struct node));
	newNode->data = item; // Create node with the specified item as its data

	newNode->next = lp->head->next; // Set the new node's next pointer to the head's next pointer
	lp->head->next = newNode; // Set the head's next pointer to the new node we are inserting
	newNode->prev = lp->head; // Set the new node's previous pointer to the head
	newNode->next->prev = newNode; // Change the next node in the list's previous pointer to point from the head to now the new node's

	lp->count++; // Count of elements incremented
}

void addLast (LIST *lp, void *item) // Inserts node into a list with data as primarily shown above, however is added at the rear-end of the queue; Runtime: O(1)
{
	struct node *newNode = malloc (sizeof(struct node));
	newNode->data = item; // Create node with the specified item as its data

	newNode->next = lp->head; // Set new node's next pointer to the head (due to nature of a circular list)
	newNode->prev = lp->head->prev; // Set new node's previous pointer to head's previous pointer

	lp->head->prev = newNode; // Set head's previous pointer to point to the new inserted node
	newNode->prev->next = newNode; // New node's previous node's next pointer is now set to the new node

	lp->count++; // Count of elements incremented
}

void *removeFirst (LIST *lp) // Function removes the first element, at the front-end of the queue and returns the data that was stored in the deleted node; Runtime: O(1)
{
	assert(lp->count>0);

	struct node *firstNode = lp->head->next; // Temporary variable used to store the first element
	void *firstData = firstNode->data; // Temporary variable used to store the first element's data

	lp->head->next = firstNode->next; // Start deleting the first node by setting the head's next pointer to the first node's next pointer
	firstNode->next->prev = lp->head; // Set the second node's previous pointer to the head, thereby cutting the first node out of the list

	free(firstNode); // Free the memory stored inside the deleted node
	lp->count--; // Count of elements decremented

	return firstData;
}

void *removeLast (LIST *lp) // Function similar to removeFirst but removes the last element, at the rear-end of the queue and returns the data that was stored in the deleted node; Runtime: O(1)
{
	assert(lp->count> 0);

	struct node *lastNode = lp->head->prev; // Temporary variable used to store last element
	void *lastData = lastNode->data; // Temporary variable used to store last element's data

	lastNode->prev->next = lp->head; // Set last node's previous's next pointer to head node
	lp->head->prev = lastNode->prev; // Set the head's previous pointer to point to the last node's previous node

	free(lastNode); // Free the memory stored inside deleted node
	lp->count--; // Count of elements decremented

	return lastData;
}

void *getFirst (LIST *lp) // Returns data of the first element in deque; Runtime: O(1)
{
	assert (lp->count>0);
	return lp->head->next->data;
}

void *getLast (LIST *lp) // Returns data of the last element in deque; Runtime: O(1)
{
	assert(lp->count>0);
	return lp->head->prev->data;
}

void removeItem (LIST *lp, void *item) // Function removes a specified element given a list and some data. It traverses the list until it finds a match between a specific node and its corresponding data. If found, we change the pointers to delete that node from the list; Runtime: O(n)
{
	assert (lp->compare != NULL && lp->count > 0 && item != NULL);
	struct node *searchNode = lp->head->next; // Reference to the node we use to traverse list
	int i;

	for (i=0; i< lp->count; i++) // For loop to traverse entire list
	{
		if (lp->compare(searchNode->data, item) == 0) // If a match is found
		{
			searchNode->prev->next = searchNode->next; // Matching node's previous's next pointer changed to matching node's next
			searchNode->next->prev = searchNode->prev; // Matching node's next's previous pointer changed to matching node's previous
			free (searchNode); // Free memory
			lp->count--; // Count of elements decremented
			break;
		}
		else
		{
			searchNode = searchNode->next; // If a match is not found, continue traversing
		}
	}
}

void *findItem (LIST *lp, void *item) // Function traverses the list and returns data of a node within the list if it matches the specific item we are looking for, similar to removeItem. If a match is not found by the end of the list, we return NULL; Runtime: O(n)
{
	assert (lp->compare != NULL && item != NULL);
	struct node *searchNode = lp->head->next; // Reference to node we use to traverse list
	int i;

	for (i=0; i<lp->count; i++) // For loop to traverse the list
	{
		if (lp->compare(searchNode->data, item) == 0) // If a match is found
		{
			return searchNode->data;
		}
		searchNode = searchNode->next;
	}
	return NULL; // If no match is found by the end, return NULL
}

void *getItems (LIST *lp) // Function returns array displaying all the data in the list; Runtime: O(n)
{
	void **array;
	array = malloc (sizeof(void*)*lp->count); // Create an array of size big enough to store all elements within list
	struct node *searchNode = lp->head->next; // Reference to node we use to traverse list
	int i;

	for (i=0; i<lp->count; i++) // For loop traverses entire list
	{
		array[i] = searchNode->data; // Copies data of each element one by one
		searchNode = searchNode->next; // Traverses to next node in list
	}
	return array;
}
