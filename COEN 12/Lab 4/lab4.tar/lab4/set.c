/* Ryan Ton
 * COEN 12
 * Lab 4
 * Tuesday 5:15pm
 */

#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include "list.h"
#define AVG_LENGTH 20

struct set
{
	int count; // Number of elements
	int length; // Length of array
	LIST **lists; // Array of strings
	int (*compare)(); // Compare function provided to us via lab tar file
	unsigned (*hash)(); // Basically strhash, but implemented within set
};
typedef struct set SET;

SET *createSet (int maxElts, int (*compare)(), unsigned (*hash)()) // Function allocates memory and initializes an empty set that keeps record of the number of elements, the length of the array, and the array itself. Additionally each index contains an empty list, which we'll fill with data hash values that make it easier to search for a specific element; Runtime: O(n)
{
	SET *sp;
	sp = malloc (sizeof(SET)); // Allocates memory for new set
	assert (sp!=NULL);

	sp->count =0; // Initializes count of elements
	sp->length = maxElts/AVG_LENGTH; // Keeps track of length of array
	sp->lists = malloc(sizeof(void*)*sp->length); // Array where the actual list exists, which stores the nodes that store the data
	sp->compare = compare;
	sp->hash = hash;

	int i;
	for (i=0; i<sp->length; i++) // Each index in the array contains an empty list, which we'll fill with nodes containing data that hash to that specific location in the array
	{
		sp->lists[i] = createList(compare); // Calls createList function, which is provided via list.c
	}

	assert (sp->lists!=NULL);
	return sp;
}

void destroySet (SET *sp) // Destroys set by freeing all memory allocated that's associated with set; Runtime: O(1)
{
	free (sp->lists); // Frees lists array
	free (sp); // Finally frees set itself
}

int numElements (SET *sp) // Returns count of elements within set; Runtime: O(1)
{
	assert (sp!=NULL);
	return sp->count;
}

void addElement (SET *sp, void *elt) // Similar to the createSet function, this function calls a function via list.c. First, we keep track of the hash location via the hash function provided to us. Then we call findItem via list.c to figure out whether that item is already in the array. If not, the new element is added to the list; Runtime: O(n)
{
	assert (sp!=NULL && elt !=NULL);
	int index = (*sp->hash)(elt)%sp->length; // Keeps track of data's hash value via hash function

	if (findItem (sp->lists[index], elt) == NULL) // If findItem was not able to find a duplicate
	{
		addFirst (sp->lists[index], elt);
		sp->count++; // Increment count of elements
	}
}

void removeElement (SET *sp, void *elt) // Similar to addElement, we make use of the hash function provided to us and other functions via list.c. First, we keep track of the hash location via the hash function provided to us and call findItem to figure out whether the item is in the array. If there's a match, we call removeItem to delete the node; Runtime: O(n)
{
	assert (sp!=NULL && elt!=NULL);
	int index = (*sp->hash)(elt)%sp->length; // Keeps track of data's hash value via hash function

	if (findItem(sp->lists[index], elt) != NULL) // If there's a match found
	{
		removeItem (sp->lists[index], elt);
		sp->count--; // Decrement count of elements
	}
}

void *findElement (SET *sp, void *elt) // Function uses findItem via list.c to search for a specific element in the array; Runtime: O(n)
{
	assert (sp!=NULL && elt!=NULL);
	int index = (*sp->hash)(elt)%sp->length; // Keeps track of data's hash value via hash function
	return findItem(sp->lists[index],elt);
}

void *getElements (SET *sp) // Returns a copy of the array that the user can manipulate. Function converts the array of linked lists into a 1-D array, which is achieved by creating a temporary array and copying the data there from the linked list via a for loop. Then we use a second for loop to copy that data into the actual array which is returned; Runtime: O(n^2)
{
	assert (sp!=NULL);
	void **array;
	array = malloc(sizeof(void*)*sp->count); // Array that we plan on returning to the user
	int i, j, copyCount = 0; 

	for (i=0; i<sp->length; i++) // For loop used to create and allocate size for the temporary array
	{
		void **copyArray = getItems(sp->lists[i]); // Temporary array used to copy the data from the linked lists and convert to 1-D array

		for (j=0; j<numItems(sp->lists[i]); j++)
		{
			array[copyCount] = copyArray[j]; // Copy count used as index as we copy the data from the temporary array to the original
			copyCount++; // As each element is copied one by one, increment index
		}
	}
	return array;
}
