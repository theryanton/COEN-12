#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#define EMPTY 0
#define FILLED 1
#define DELETED 2

struct set
{
	int count; // Number of elements
	int length; // Length of actual array
	char **data; // Array recording strings
	char* flags; // Array of flags used to help traverse arrays
};
typedef struct set SET;

unsigned strhash (char *s) // Assigns a unique hash value for each string via running through each character and multiplying its value by 31 and summing these values; Runtime: O(1)
{
	unsigned hash = 0;
	while (*s != 0) 
	{
		hash = 31 * hash + *s ++;
	}
	return hash;
}

SET *createSet (int maxElts) // Function allocates memory and initializes an empty set that keeps record of number of elements, length of array, and the array itself. Also creates flags that aid with traversing array; Runtime: O(n)
{
	SET *sp;
	sp = malloc (sizeof(SET)); // Create set
	assert (sp!=NULL);

	sp->count = 0;
	sp->length = maxElts;
	sp->data = malloc(sizeof(char*)*maxElts);
	sp->flags = malloc(sizeof(char)*maxElts);

	int i;
	for (i=0; i<maxElts; i++) // For loop initializes all elements within new array as empty
	{
		sp->flags[i] = EMPTY;
	}
	assert (sp->data != NULL);
	return sp;
}

void destroySet (SET *sp) // Destroys set by freeing the memory allocated for the elements stored within data array, the data array itself, the flags array, then finally the set itself; Runtime: O(n)
{
	int i;
	for (i=0; i<sp->length; i++)
	{
		if (sp->flags[i] == FILLED) // Using for loop, checks to see if flags corresponding to elements signify that the indexes are filled
		{
			free (sp->data[i]); // Frees data stored within those indexes
		}
	}
	free (sp->flags); // Frees flags array
	free (sp->data); // Frees data array
	free (sp); // Frees set itself
}

int numElements (SET *sp) // Returns count of elements within set; Runtime: O(1)
{
	assert (sp!=NULL);
	return sp->count;
}

int search (SET *sp, char *elt, bool *found) // Performs a search through linear probing, runs by assigning a starting hash value and keeping track of a deleted location. As it iterates through array with for loop, if the location is FILLED, the element has been found and the function simply returns its index. If DELETED, a variable is used to record the location of the first deleted element. Otherwise, if EMPTY, this means the element was not found in this array, and if no deleted location was recorded, the function returns the empty index at the end. If a deleted location was found, the function will return its index instead; Expected runtime: O(1), Worst runtime: O(n)
{
	int i, locn;
	int head = strhash(elt) % sp->length;
	int deletedlocn = -1; // Variable keeping track of deleted location
	for (i=0; i<sp->length; i++)
	{
		locn = (head + i) % sp->length; // Assigned start hash value
		if (sp->flags[locn] == FILLED) // FILLED means found so we return its location
		{
			if (strcmp (sp->data[locn],elt) == 0)
			{
				*found = true;
				return locn;
			}
		}
		else if (sp->flags[locn] == DELETED) // DELETED means the element we're searching for could still be later down the array
		{
			if (deletedlocn == -1)
			{
				deletedlocn = locn;
			}
		}
		else // Otherwise, EMPTY signifies element was not found throughout array
		{
			break;
		}
	}
	*found = false;
	if (deletedlocn == -1) // If variable has not changed, return empty index at the end
	{
		return locn;
	}
	return deletedlocn; // Otherwise, return the first deleted location found
}

void addElement (SET *sp, char *elt) // Performs a search via search function to look for whether inserted element already exists. If not found, we insert the new element into an index and assign the corresponding flag to FILLED; Expected runtime: O(1), Worst runtime: O(n)
{
	assert (sp!=NULL && elt != NULL);
	bool searched;
	int index = search (sp, elt, &searched);
	
	if (searched == false)
	{
		sp->data[index] = strdup(elt); // New element inserted into index
		sp->flags[index] = FILLED; // Corresponding flag set to FILLED
		sp->count++; // Count of elements incremented
	}
}

void removeElement (SET *sp, char *elt) // Performs a search via search function to look for whether a specific element exists within array. If found, we free the memory at the location and assign its corresponding flag to DELETED; Expected runtime: O(1), Worst runtime: O(n)
{
	assert(sp!=NULL && elt!=NULL);
	bool searched;
	int index = search(sp, elt, &searched);

	if (searched==true)
	{
		free (sp->data[index]); // Frees memory at corresponding location
		sp->flags[index] = DELETED; // Sets the flag with the same index in the flags array to DELETED
		sp->count--; // Count of elements decremented
	}
}

char *findElement (SET *sp, char *elt) // Utilizes search function, if search returns as true, we have therefore found the element. Otherwise, returns NULL; Expected runtime: O(1), Worst runtime: O(n)
{
	assert(sp!=NULL && elt!=NULL);
	bool searched;
	int index = search(sp, elt, &searched);
	if (searched==true)
	{
		return sp->data[index];
	}
	else
	{
		return NULL;
	}
}

char **getElements(SET *sp) // Returns a copy of array that user can manipulate; Runtime: O(n)
{
	assert(sp!=NULL);
	char **arr;
	int i;
	int last = 0; // Last index in array
	arr = malloc(sizeof(char*)*sp->count);	// Declaring array and allocating memory to be equal to number of elements
	for (i=0; i<sp->length; i++)
	{
		if (sp->flags[i] == FILLED)
		{
			arr[last]=strdup(sp->data[i]); // Copies each element within array one by one
			last++; // Keeps tracj of size of array, increases as elements are copied				
		}
	}
	return arr;
}
