/* Ryan Ton
 * COEN 12
 * Term Project
 * Tuesday 5:15pm
 */

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "list.h"
#define START_LENGTH 10

typedef struct node // Basic struct that will be the foundation for building our linked list; Stores data as well as pointers to next and previous nodes
{
	void **data; // Initiated storage for data
	struct node *prev; // Points to previous node
	struct node *next; // Points to next node
	int first; // Keeps track of location of first element within the array of data
	int counter; // Keeps track of total count of existing elements within the array of data
	int length; // Maximum amount of elements the array can store
} NODE;

typedef struct list // Overall struct maintaining doubly linked list; Contains a counter for the overall nodes it has, with head and tail pointers
{
	int nodes; // Keeps track of total amount of nodes within the linked list
	NODE *head; // Points to head node
	NODE *tail; // Points to tail node
} LIST;

NODE *createNode (int length); // Prototype declaration for createNode function

LIST *createList (void) // Function allocates storage for a doubly linked list and calls the createNode function to allocate storage for an array within each node; Runtime: O(1)
{
	LIST *lp;
	lp = malloc(sizeof(LIST));
	assert (lp!=NULL);

	lp->head = lp->tail = createNode(START_LENGTH); // Calls createNode function to allocate an initial amount of nodes, which I've arbitrarily set to 10, sets pointers to point to list
	lp->nodes = 0; // Sets initial count of nodes in linked list to 0
	return lp; // Returns list pointer
}

NODE *createNode (int length) // Function allocates storage for an array within each node of the list; Runtime: O(1)
{
	NODE *np;
	np = malloc(sizeof(NODE));
	assert (np!=NULL);

	np->length = length; // Sets the initial maximum limit of indexes in array to 10, will dynamically shift over time
	np->data = malloc(sizeof(void**) * length); // Allocate memory for array within each node, with amount of indexes determined by length 
	np->first = 0; // Sets index of first element to 0
	np->counter = 0; // Initial count of existing elements inside array set to 0
	np->prev = NULL; // First node initially points to null
	np->next = NULL;
	return np; // Returns node pointer
}

void destroyList (LIST *lp) // Function traverses entire list with a pointer and frees the memory allocated for the entire list; Runtime: O(n)
{
	assert (lp!=NULL);

	NODE *pDelete; // Pointer that will traverse the linked list
	while (lp->head != NULL) // While the list exists
	{
		pDelete = lp->head; // Point to head node, and one by one, traverse the list
		lp->head = lp->head->next;
		free (pDelete->data); // Free memory allocated within each node for arrays
		free (pDelete); // Frees the nodes in the linked list
	}
	free (lp); // Finally frees the list itself
}

int numItems (LIST *lp) // Simply returns the current count of nodes within the linked list; Runtime: O(1)
{
	assert (lp!=NULL);
	return lp->nodes;
}

void addFirst (LIST *lp, void *item) // Function adds a new element into the array within the first node of the linked list. First checks whether the amount of existing elements inside the array exceed the determined maximum length, and if so, will allocate a new node with an increased amount of indexes by factor of 2; Runtime: O(1)
{
	assert (lp!=NULL && item!=NULL);

	if (lp->head->counter == lp->head->length) // Checks whether amount of existing items in array exceed maximum length
	{
		NODE *newNode = createNode (lp->head->length * 2); // If so, calls the createNode function to allocate a new node with an increased amount of indexes by a factor of 2
		newNode->next = lp->head; // Set the new node's next pointer to point to current head
		lp->head = newNode; // Set head pointer to new node
		newNode->next->prev = newNode; // Set previous head's previous pointer to point to inserted node
	}
	
	int index = ((lp->head->first + lp->head->length - 1) % lp->head->length); // Variable used to keep track of the index of the inserted item

	lp->head->data[index] = item; // Insert item into array
	lp->head->first = index; // Set first variable within head node's array to this item's index 
	lp->head->counter++; // Increment count of elements inside head node's array
	lp->nodes++; // Increment count of total nodes
}

void addLast (LIST *lp, void *item) // Function adds a new element into te array within the last node of the linked list. First checks whether the amount of existing elements inside the array exceed the determined maximum length, and if so, will allocate a new node with an increased amount of indexes by factor of 2; Runtime: O(1) 
{
	assert (lp!=NULL && item!=NULL);

	if (lp->tail->counter == lp->head->length) // Checks whether amount of existing items in array exceed maximum length
	{
		NODE *newNode = createNode (lp->head->length * 2); // If so, calls the createNode function to allocate a new node with an increased amount of indexes by a factor of 2
		newNode->prev = lp->tail; // Set the new node's previous pointer to point to current tail
		lp->tail->next = newNode; // Set current tail's next pointer to point to new node
		lp->tail = newNode; // Set tail pointer to new node
		newNode->next = NULL; // Set next pointer to null
	}

	int index = ((lp->tail->first + lp->tail->counter) % lp->tail->length); // Variable used to keep track of the index of the inserted item

	lp->tail->data[index] = item; // Insert item into array
	lp->tail->counter++; // Increment count of elements inside head node's array
	lp->nodes++; // Increment count of total nodes
}

void *removeFirst (LIST *lp) // Function removes and returns the first item in the list's head node after checking whether that node is empty or not. If it is empty, it moves onto the next node until it finds one with data; Runtime: O(1)
{
	assert (lp!=NULL);

	if (lp->head->counter == 0) // Checks if the head node's array is empty
	{
		lp->head = lp->head->next; // If so, set the head pointer to the next node
		free (lp->head->prev); // Free previous head node
		lp->head->prev = NULL; // Set new head's previous pointer to null
	}

	int deletedlocn = lp->head->first; // Variable used to keep track of the location of the item we're deleting
	int newFirst = ((deletedlocn + 1) % lp->head->length); // Variable used to keep track of the index of the new first element of the array
	lp->head->first = newFirst; // Set first variable within head node's array to new first element's index

	void *firstData = lp->head->data[deletedlocn]; // Temporary variable used to store the first element's data
	lp->head->counter--; // Decrement count of elements inside head node's array
	lp->nodes--; // Decrement count of total nodes
	return firstData;
}

void *removeLast (LIST *lp) // Function removes and returns the last item in the list's tail node after checking whether that node is empty or not. If it is empty, it moves onto the previous node until it finds one with data; Runtime: O(1)
{
	assert (lp!=NULL);

	if (lp->tail->counter == 0) // Checks if the tail node's array is empty
	{
		NODE *deletedNode = lp->tail; // If so, set a pointer to point to the current tail
		lp->tail = lp->tail->prev; // Set the tail's previous node as the new tail
		lp->tail->next = NULL; // Set the new tail's next pointer to null
		free (deletedNode->data); // Free previous tail node
		free (deletedNode);
	}

	int deletedlocn = ((lp->tail->first + lp->tail->counter) % lp->tail->length); // Variable used to keep track of the location of the item we're deleting

	void *lastData = lp->tail->data[deletedlocn]; // Temporary variable used to store the last element's data
	lp->tail->counter--; // Decrement count of elements inside tail node's array
	lp->nodes--; // Decrement count of total nodes
	return lastData;
}

void *getItem (LIST *lp, int index) // Function returns the item at a specific index, given it's within range. As the list is traversed, the counter is decremented until it reaches that specific index and returns the data stored there; Runtime: O(log n)
{
	assert (lp!=NULL);
	assert (index >= 0 && index < lp->nodes);

	NODE *pTraverse = lp->head; // Pointer used to traverse the list
	while (index >= pTraverse->counter) // While the index we're searching for is greater than the count of existing elements within the array
	{
		index -= pTraverse->counter; // Decrement count of existing elements within array as pointer traverses
		pTraverse = pTraverse->next;
	}

	void *searchData = pTraverse->data[(pTraverse->first + index) % pTraverse->length]; // Temporary variable used to store the found element's data
	return searchData;
}

void setItem (LIST *lp, int index, void *item) // Function operates similarly to getItem, but inserts a new element at a specific index instead of returning data there; Runtime: O(log n) 
{
	assert (lp!=NULL);
	assert (index >= 0 && index < lp->nodes);
	assert (item!=NULL);

	NODE *pTraverse = lp->head; // Pointer used to traverse the list
	while (index >= pTraverse->counter) // While the index we're searching for is greater than the count of existing elements within the array
	{
		index -= pTraverse->counter; // Decrement count of existing elements within array as pointer traverses
		pTraverse = pTraverse->next;
	}
	pTraverse->data[(pTraverse->first + index) % pTraverse->length] = item; // Places new item inside the index we traversed for
}
